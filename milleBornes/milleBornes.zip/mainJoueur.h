#ifndef MAINJOUEUR_H
#define MAINJOUEUR_H

#include <iostream>
#include <string>
#include <vector>
#include "Cartes.h"
#include "Deck.h"

class mainJoueur
{
public:
    //mainJoueur();
    //void ajouterCarte(Cartes* c);
    //void afficher();
    //void distribuer(Deck*);
    //void pioche();
   // void choisir(int tour, int choix, Deck* deck);
    //vector<Cartes*> getPioche() { return this->cartesPioche; }
    //vector<Cartes*> getMain() { return this->cartes; }
    
protected:

private:

    vector<Cartes*> cartesPioche;
    //vector<Cartes*> cartes;


};

#endif // MAINJOUEUR_H
